import streamlit as st
import requests
import json
import pandas as pd
import firebase_admin
from firebase_admin import auth
from firebase_admin import credentials

# Initialize Firebase
cred = credentials.Certificate('insightify-141f7-14c8249a9764.json')

if not firebase_admin._apps:
    firebase_admin.initialize_app(cred)

# Firebase API Key
FIREBASE_API_KEY = "AIzaSyApr-etDzcGcsVcmaw7R7rPxx3A09as7uw"

def sign_up_with_email_and_password(email, password, username=None):
    try:
        rest_api_url = "https://identitytoolkit.googleapis.com/v1/accounts:signUp"
        payload = {
            "email": email,
            "password": password,
            "returnSecureToken": True
        }
        if username:
            payload["displayName"] = username

        r = requests.post(rest_api_url, params={"key": FIREBASE_API_KEY}, json=payload)
        data = r.json()

        if "email" in data:
            return data['email']
        else:
            st.warning(f"Signup failed: {data.get('error', {}).get('message', 'Unknown error')}")
            return None
    except Exception as e:
        st.warning(f'Signup failed: {e}')
        return None

def sign_in_with_email_and_password(email, password):
    try:
        rest_api_url = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword"
        payload = {
            "email": email,
            "password": password,
            "returnSecureToken": True
        }
        r = requests.post(rest_api_url, params={"key": FIREBASE_API_KEY}, json=payload)
        data = r.json()

        if "email" in data:
            return {
                'email': data['email'],
                'username': data.get('displayName', 'User')
            }
        else:
            st.warning(f"Login failed: {data.get('error', {}).get('message', 'Unknown error')}")
            return None
    except Exception as e:
        st.warning(f'Signin failed: {e}')
        return None

def reset_password(email):
    try:
        rest_api_url = "https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode"
        payload = {
            "email": email,
            "requestType": "PASSWORD_RESET"
        }
        r = requests.post(rest_api_url, params={"key": FIREBASE_API_KEY}, json=payload)

        if r.status_code == 200:
            return True, "Reset email Sent"
        else:
            error_message = r.json().get('error', {}).get('message', 'Unknown error')
            return False, error_message
    except Exception as e:
        return False, str(e)

def login():
    userinfo = sign_in_with_email_and_password(st.session_state.email_input, st.session_state.password_input)
    if userinfo:
        st.session_state.username = userinfo['username']
        st.session_state.useremail = userinfo['email']
        st.session_state.signedout = True
        st.session_state.signout = True
    else:
        st.warning('Login Failed')

def logout():
    st.session_state.signout = False
    st.session_state.signedout = False
    st.session_state.username = ''
    st.session_state.useremail = ''

def forget_password():
    email = st.text_input('Email')
    if st.button('Send Reset Link'):
        success, message = reset_password(email)
        if success:
            st.success("Password reset email sent successfully.")
        else:
            st.warning(f"Password reset failed: {message}")

def app():
    st.title('Welcome to :violet[Insightify] :sunglasses:')

    if 'username' not in st.session_state:
        st.session_state.username = ''
    if 'useremail' not in st.session_state:
        st.session_state.useremail = ''
    if "signedout" not in st.session_state:
        st.session_state["signedout"] = False
    if 'signout' not in st.session_state:
        st.session_state['signout'] = False    

    if not st.session_state["signedout"]:
        choice = st.selectbox('Login/Signup', ['Login', 'Sign up'])
        email = st.text_input('Email Address')
        password = st.text_input('Password', type='password')

        st.session_state.email_input = email
        st.session_state.password_input = password

        if choice == 'Sign up':
            username = st.text_input("Enter your unique username")
            if st.button('Create my account'):
                user = sign_up_with_email_and_password(email, password, username)
                if user:
                    st.success('Account created successfully!')
                    st.markdown('Please login using your email and password')
                    st.balloons()
        else:
            st.button('Login', on_click=login)
            forget_password()
            
    if st.session_state.signout:
        st.text('Name: ' + st.session_state.username)
        st.text('Email ID: ' + st.session_state.useremail)
        st.button('Sign out', on_click=logout)

def app():
    st.write('Posts')
